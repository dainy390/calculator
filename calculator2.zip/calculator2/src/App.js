import Calculator from "./componant/Calculator";
function App() {
  return (
    <>
      <Calculator />
    </>
  );
}

export default App;